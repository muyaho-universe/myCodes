//21800059 김대석 나대영 교수님 C 프로그래밍 01분반 과제 2-1
#include <stdio.h>

int main(void) {
  int i; //반복을 위한 변수

  for(i=10; i>=1; i--){ //역순으로 반복시작
    printf("%2d", i);

  }
  return 0;
}