//21800059 김대석 나대영 교수님 C 프로그래밍 01분반 과제 2-6
#include <stdio.h>

int main(){
    int i, j; //반복을 위한 변수
    int sum; //둘의 값을 더하기 위한 변수 sum
    int count = 0; //횟수를 세기위한 변수

    for(i=9; i<=90; i+=9){
        for (j = 90; j >= 9; j-=9) {
            sum= i + j;
            if(sum == 99){
                printf("%02d+%02d=99\n", i, j);
            }
            if(j==9){ //j가 9보다 작아지게 되면 계산할 필요가 없어지므로 여기서 멈추게 한다.
              break;
            }
            count ++;
        }
        
    }
    printf("count:%d\n", count);
}